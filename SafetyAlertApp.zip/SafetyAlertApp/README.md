# Safety Alert — Java full-stack starter

A responsive Spring Boot + Thymeleaf web app for **police-authorized public safety notices**. Includes missing-child and official wanted-notice categories, photo upload, public alert pages, a police dashboard, and marking an alert resolved.

## Requirements
- Java 17+
- Maven 3.9+ (or use your IDE's Maven support)

## Run
1. Extract this ZIP.
2. Open the `SafetyAlertApp` folder in VS Code or IntelliJ.
3. In a terminal opened in that folder, run:
   ```bash
   mvn spring-boot:run
   ```
4. Open `http://localhost:8080`.
5. Demo police login:
   - Username: `police`
   - Password: `ChangeMe-123!`

Change the demo credentials before use. For example, Linux/macOS:
```bash
export POLICE_USERNAME=stationadmin
export POLICE_PASSWORD='use-a-long-unique-password'
mvn spring-boot:run
```
PowerShell:
```powershell
$env:POLICE_USERNAME="stationadmin"
$env:POLICE_PASSWORD="use-a-long-unique-password"
mvn spring-boot:run
```

## How it works
- Public visitors can view active notices and official station contact details.
- Only the signed-in `POLICE` role can create notices or mark them resolved.
- Uploaded photos are restricted to JPG, PNG, or WEBP and 5 MB.
- Data is stored in a local H2 file database; uploaded photos are stored in `uploads/`.

## Important before real deployment
This is an educational MVP, **not a production police notification system**. It does not send SMS, push notifications, or email. It also does not verify that a user is really a police officer; the single demo account is only a local development mechanism. Before public deployment, work with the relevant police department to add verified staff accounts, strong authentication/MFA, audit logs, approval workflow, alert expiry, rate limiting, secure cloud storage, backups, HTTPS, privacy/legal review, and a reliable SMS/push provider. Use only information approved for public release. Do not expose live tracking or private addresses, encourage public confrontation, or allow crowdsourced accusations. Provide a way for the police to correct or withdraw an alert quickly.
