package in.safetyalert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafetyAlertApplication {
    public static void main(String[] args) {
        SpringApplication.run(SafetyAlertApplication.class, args);
    }
}
