package in.safetyalert.controller;

import in.safetyalert.model.SafetyAlert;
import in.safetyalert.repository.SafetyAlertRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.Set;
import java.util.UUID;

@Controller
public class WebController {
    private final SafetyAlertRepository repository;
    private final Path uploadDir;
    private static final Set<String> ALLOWED_TYPES = Set.of("image/jpeg", "image/png", "image/webp");

    public WebController(SafetyAlertRepository repository,
            @Value("${app.upload-dir:uploads}") String uploadDirectory) throws IOException {
        this.repository = repository;
        this.uploadDir = Paths.get(uploadDirectory).toAbsolutePath().normalize();
        Files.createDirectories(this.uploadDir);
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("alerts", repository.findByStatusOrderByCreatedAtDesc("ACTIVE"));
        return "index";
    }

    @GetMapping("/alerts/{id}")
    public String detail(@PathVariable Long id, Model model) {
        SafetyAlert alert = repository.findById(id).orElseThrow();
        model.addAttribute("alert", alert);
        return "detail";
    }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/police")
    public String policeDashboard(Model model) {
        model.addAttribute("alerts", repository.findAll());
        return "police";
    }

    @GetMapping("/police/new")
    public String newAlert(Model model) {
        model.addAttribute("alert", new SafetyAlert());
        return "new-alert";
    }

    @PostMapping("/police/new")
    public String createAlert(@Valid @ModelAttribute("alert") SafetyAlert alert,
            BindingResult bindingResult,
            @RequestParam(value = "photo", required = false) MultipartFile photo,
            Model model, RedirectAttributes redirectAttributes) throws IOException {

        if (photo != null && !photo.isEmpty()) {
            if (!ALLOWED_TYPES.contains(photo.getContentType())) {
                bindingResult.reject("photo.type", "Photo must be JPG, PNG, or WEBP.");
            } else if (photo.getSize() > 5 * 1024 * 1024) {
                bindingResult.reject("photo.size", "Photo must be 5 MB or smaller.");
            }
        }
        if (bindingResult.hasErrors()) return "new-alert";

        if (photo != null && !photo.isEmpty()) {
            String extension = switch (photo.getContentType()) {
                case "image/jpeg" -> ".jpg";
                case "image/png" -> ".png";
                case "image/webp" -> ".webp";
                default -> throw new IllegalArgumentException("Unsupported image type");
            };
            String safeName = UUID.randomUUID() + extension;
            Path target = uploadDir.resolve(safeName).normalize();
            if (!target.startsWith(uploadDir)) throw new IOException("Invalid upload path");
            photo.transferTo(target);
            alert.setPhotoFilename(safeName);
        }
        alert.setStatus("ACTIVE");
        repository.save(alert);
        redirectAttributes.addFlashAttribute("message", "Official alert published.");
        return "redirect:/police";
    }

    @PostMapping("/police/{id}/resolve")
    public String resolveAlert(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        repository.findById(id).ifPresent(alert -> {
            alert.setStatus("RESOLVED");
            repository.save(alert);
        });
        redirectAttributes.addFlashAttribute("message", "Alert marked resolved.");
        return "redirect:/police";
    }

    @GetMapping("/uploads/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> photo(@PathVariable String filename) throws MalformedURLException {
        // Only serve a simple filename from the configured upload directory.
        if (filename.contains("/") || filename.contains("\\") || filename.contains(".."))
            return ResponseEntity.badRequest().build();
        Path file = uploadDir.resolve(filename).normalize();
        if (!file.startsWith(uploadDir) || !Files.exists(file))
            return ResponseEntity.notFound().build();
        Resource resource = new UrlResource(file.toUri());
        return ResponseEntity.ok()
                .header(HttpHeaders.X_CONTENT_TYPE_OPTIONS, "nosniff")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }
}
