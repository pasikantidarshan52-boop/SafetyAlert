package in.safetyalert.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
public class SafetyAlert {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Size(max = 30)
    private String type; // MISSING_CHILD or OFFICIAL_WANTED_NOTICE

    @NotBlank @Size(max = 120)
    private String title;

    @NotBlank @Size(max = 3000)
    @Column(length = 3000)
    private String details;

    @NotBlank @Size(max = 200)
    private String lastKnownArea; // Broad public area only; do not publish live tracking data.

    @NotBlank @Size(max = 150)
    private String policeStation;

    @NotBlank @Size(max = 40)
    private String policeContact;

    @Size(max = 255)
    private String photoFilename;

    @NotBlank @Size(max = 40)
    private String status = "ACTIVE";

    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
    public String getLastKnownArea() { return lastKnownArea; }
    public void setLastKnownArea(String lastKnownArea) { this.lastKnownArea = lastKnownArea; }
    public String getPoliceStation() { return policeStation; }
    public void setPoliceStation(String policeStation) { this.policeStation = policeStation; }
    public String getPoliceContact() { return policeContact; }
    public void setPoliceContact(String policeContact) { this.policeContact = policeContact; }
    public String getPhotoFilename() { return photoFilename; }
    public void setPhotoFilename(String photoFilename) { this.photoFilename = photoFilename; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
