package in.safetyalert.repository;

import in.safetyalert.model.SafetyAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SafetyAlertRepository extends JpaRepository<SafetyAlert, Long> {
    List<SafetyAlert> findByStatusOrderByCreatedAtDesc(String status);
}
